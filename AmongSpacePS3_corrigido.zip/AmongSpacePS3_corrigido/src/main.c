#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#define W 1280
#define H 720
#define PLAYER_SPEED 230.0f

typedef struct { float x, y; SDL_Color color; } Crew;
typedef struct { SDL_Rect r; bool done; } Task;

static void fill(SDL_Renderer *r, int x, int y, int w, int h, SDL_Color c) {
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
    SDL_Rect q = {x,y,w,h}; SDL_RenderFillRect(r, &q);
}
static void outline(SDL_Renderer *r, int x, int y, int w, int h, SDL_Color c) {
    SDL_SetRenderDrawColor(r, c.r, c.g, c.b, c.a);
    SDL_Rect q = {x,y,w,h}; SDL_RenderDrawRect(r, &q);
}
static void text_bar(SDL_Renderer *r, int x, int y, int width, SDL_Color c) {
    fill(r,x,y,width,5,c);
}
static void draw_crew(SDL_Renderer *r, int x, int y, SDL_Color c) {
    fill(r,x-13,y-2,26,31,c);
    fill(r,x-10,y-15,20,24,c);
    fill(r,x-12,y+22,9,10,c);
    fill(r,x+3,y+22,9,10,c);
    fill(r,x-8,y-12,20,11,(SDL_Color){12,22,35,255});
    fill(r,x-6,y-10,16,7,(SDL_Color){115,220,255,255});
    outline(r,x-13,y-15,26,47,(SDL_Color){15,20,28,255});
}
static float dist2(float x1,float y1,float x2,float y2) {
    float dx=x1-x2, dy=y1-y2; return dx*dx+dy*dy;
}
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    if (SDL_Init(SDL_INIT_VIDEO|SDL_INIT_GAMECONTROLLER) != 0) {
        fprintf(stderr,"SDL_Init: %s\n",SDL_GetError()); return 1;
    }
    SDL_Window *win=SDL_CreateWindow("Among Space PS3 - prototipo",
        SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,W,H,SDL_WINDOW_SHOWN);
    if(!win){fprintf(stderr,"Window: %s\n",SDL_GetError());SDL_Quit();return 1;}
    SDL_Renderer *ren=SDL_CreateRenderer(win,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
    if(!ren) ren=SDL_CreateRenderer(win,-1,SDL_RENDERER_SOFTWARE);
    if(!ren){SDL_DestroyWindow(win);SDL_Quit();return 1;}

    Crew player={640,385,{225,48,65,255}};
    Crew npcs[3]={{430,300,{40,115,235,255}},{835,330,{45,190,95,255}},{520,520,{170,65,205,255}}};
    Task tasks[3]={{{260,180,44,44},false},{{950,190,44,44},false},{{980,520,44,44},false}};
    bool running=true, meeting=false;
    int completed=0;
    Uint32 last=SDL_GetTicks();
    SDL_GameController *pad=NULL;
    for(int i=0;i<SDL_NumJoysticks();i++) if(SDL_IsGameController(i)){pad=SDL_GameControllerOpen(i);break;}

    while(running){
        Uint32 now=SDL_GetTicks(); float dt=(now-last)/1000.0f; last=now;
        if(dt>0.05f)dt=0.05f;
        SDL_Event e;
        while(SDL_PollEvent(&e)){
            if(e.type==SDL_QUIT)running=false;
            if(e.type==SDL_KEYDOWN){
                if(e.key.keysym.sym==SDLK_ESCAPE)running=false;
                if(e.key.keysym.sym==SDLK_r)meeting=!meeting;
                if(e.key.keysym.sym==SDLK_e){
                    for(int i=0;i<3;i++) if(!tasks[i].done &&
                       dist2(player.x,player.y,tasks[i].r.x+22,tasks[i].r.y+22)<85*85){
                        tasks[i].done=true;completed++;break;
                    }
                }
            }
            if(e.type==SDL_CONTROLLERBUTTONDOWN){
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_B) meeting=!meeting;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A){
                    for(int i=0;i<3;i++) if(!tasks[i].done &&
                       dist2(player.x,player.y,tasks[i].r.x+22,tasks[i].r.y+22)<85*85){
                        tasks[i].done=true;completed++;break;
                    }
                }
            }
        }
        const Uint8 *k=SDL_GetKeyboardState(NULL);
        float dx=(k[SDL_SCANCODE_RIGHT]||k[SDL_SCANCODE_D])-(k[SDL_SCANCODE_LEFT]||k[SDL_SCANCODE_A]);
        float dy=(k[SDL_SCANCODE_DOWN]||k[SDL_SCANCODE_S])-(k[SDL_SCANCODE_UP]||k[SDL_SCANCODE_W]);
        if(pad){
            Sint16 ax=SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTX);
            Sint16 ay=SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTY);
            if(abs(ax)>7000)dx=ax/32767.0f;
            if(abs(ay)>7000)dy=ay/32767.0f;
        }
        float len=sqrtf(dx*dx+dy*dy); if(len>1){dx/=len;dy/=len;}
        player.x+=dx*PLAYER_SPEED*dt; player.y+=dy*PLAYER_SPEED*dt;
        if(player.x<55)player.x=55;if(player.x>1225)player.x=1225;
        if(player.y<105)player.y=105;if(player.y>650)player.y=650;

        SDL_SetRenderDrawColor(ren,12,20,32,255);SDL_RenderClear(ren);
        fill(ren,40,75,1200,590,(SDL_Color){55,67,82,255});
        /* piso em grade */
        SDL_SetRenderDrawColor(ren,82,96,110,255);
        for(int x=50;x<1240;x+=48)SDL_RenderDrawLine(ren,x,80,x,660);
        for(int y=90;y<660;y+=48)SDL_RenderDrawLine(ren,45,y,1235,y);
        /* paredes e mesas */
        fill(ren,500,210,280,110,(SDL_Color){30,105,170,255});
        outline(ren,500,210,280,110,(SDL_Color){8,25,42,255});
        fill(ren,520,475,240,95,(SDL_Color){30,105,170,255});
        outline(ren,520,475,240,95,(SDL_Color){8,25,42,255});
        /* terminais de tarefa */
        for(int i=0;i<3;i++){
            SDL_Color tc=tasks[i].done?(SDL_Color){45,190,105,255}:(SDL_Color){245,185,45,255};
            fill(ren,tasks[i].r.x,tasks[i].r.y,44,44,tc);
            outline(ren,tasks[i].r.x,tasks[i].r.y,44,44,(SDL_Color){8,20,30,255});
        }
        for(int i=0;i<3;i++)draw_crew(ren,(int)npcs[i].x,(int)npcs[i].y,npcs[i].color);
        draw_crew(ren,(int)player.x,(int)player.y,player.color);

        /* HUD */
        fill(ren,16,14,390,45,(SDL_Color){15,25,38,230});
        outline(ren,16,14,390,45,(SDL_Color){70,220,125,255});
        text_bar(ren,28,27,completed*112,(SDL_Color){55,220,120,255});
        fill(ren,16,70,310,125,(SDL_Color){15,25,38,230});
        outline(ren,16,70,310,125,(SDL_Color){160,180,200,255});
        for(int i=0;i<3;i++)text_bar(ren,32,92+i*30, tasks[i].done?210:150,
            tasks[i].done?(SDL_Color){70,210,120,255}:(SDL_Color){225,225,235,255});
        fill(ren,1060,20,190,125,(SDL_Color){10,30,65,255});
        outline(ren,1060,20,190,125,(SDL_Color){75,150,255,255});
        fill(ren,1120,65,55,35,(SDL_Color){30,90,210,255});
        fill(ren,1090,105,125,20,(SDL_Color){30,90,210,255});
        if(meeting){
            fill(ren,390,260,500,170,(SDL_Color){20,25,38,245});
            outline(ren,390,260,500,170,(SDL_Color){255,75,75,255});
            text_bar(ren,440,305,400,(SDL_Color){255,255,255,255});
            text_bar(ren,470,355,340,(SDL_Color){255,85,85,255});
        }
        SDL_RenderPresent(ren);
    }
    if(pad)SDL_GameControllerClose(pad);
    SDL_DestroyRenderer(ren);SDL_DestroyWindow(win);SDL_Quit();return 0;
}
